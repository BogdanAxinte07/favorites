import { createContext } from "react";

// Cream un context asociat temei.
export const ThemeContext = createContext();
