// Actiune ce seteaza tema deschisa:
export function setLightTheme() {
  return {
    type: "LIGHT"
  };
}

// Actiune ce seteaza tema inchisa:
export function setDarkTheme() {
  return {
    type: "DARK"
  };
}
