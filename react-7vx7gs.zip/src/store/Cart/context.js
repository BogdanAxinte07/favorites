import { createContext } from "react";

// Cream contextul aferent cartului.
export const CartContext = createContext();
